function searchMusic() {
    var searchTerm = document.getElementById('searchInput').value;
    var resultsSection = document.getElementById('results');
    resultsSection.innerHTML = '';

    // Simulate search results (replace this with actual API call)
    var mockResults = [
        { title: 'Song 1', artist: 'Artist 1' },
        { title: 'Song 2', artist: 'Artist 2' },
        { title: 'Song 3', artist: 'Artist 3' }
    ];

    mockResults.forEach(function(result) {
        var resultDiv = document.createElement('div');
        resultDiv.classList.add('result');
        var titleElement = document.createElement('h3');
        titleElement.textContent = result.title;
        var artistElement = document.createElement('p');
        artistElement.textContent = 'Artist: ' + result.artist;

        resultDiv.appendChild(titleElement);
        resultDiv.appendChild(artistElement);
        resultsSection.appendChild(resultDiv);
    });
}
